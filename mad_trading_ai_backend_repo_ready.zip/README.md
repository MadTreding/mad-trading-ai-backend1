# MaD Trading AI - Backend

Questo è il backend per MaD Trading AI, una piattaforma che analizza screenshot di grafici e restituisce segnali LONG/SHORT con percentuale di successo e motivazioni realistiche.

## Tecnologie
- FastAPI
- Uvicorn
- OCR simulato (per ora)

## Come avviare in locale
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

## Endpoint
- POST `/analyze` con immagine => risposta AI

## Deploy su Render
- Build command: `pip install -r requirements.txt`
- Start command: `uvicorn main:app --host 0.0.0.0 --port 10000`