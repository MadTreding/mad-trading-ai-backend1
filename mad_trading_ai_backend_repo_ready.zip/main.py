from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from random import choice, randint, uniform
import uvicorn

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/analyze")
async def analyze_image(file: UploadFile = File(...)):
    # Simulazione logica AI visiva: risposte realistiche casuali
    signal = choice(["LONG", "SHORT"])
    success_rate = round(uniform(55, 90) if signal == "LONG" else uniform(40, 80), 2)
    entry = round(uniform(1.1000, 2.5000), 4)
    stop_loss = round(entry - uniform(0.01, 0.05), 4)
    take_profit = round(entry + uniform(0.02, 0.08), 4)

    reasons = []
    if signal == "LONG":
        reasons = [
            "CHoCH confermato sopra supporto",
            "RSI in zona ipervenduto",
            "Engulfing rialzista",
            "Volume in aumento",
        ]
    else:
        reasons = [
            "Break of Structure ribassista",
            "RSI in ipercomprato",
            "Candela di inversione visibile",
            "Prezzo sotto media mobile",
        ]

    return {
        "signal": signal,
        "success_rate": success_rate,
        "entry": entry,
        "stop_loss": stop_loss,
        "take_profit": take_profit,
        "reasons": reasons[:3]
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=10000)